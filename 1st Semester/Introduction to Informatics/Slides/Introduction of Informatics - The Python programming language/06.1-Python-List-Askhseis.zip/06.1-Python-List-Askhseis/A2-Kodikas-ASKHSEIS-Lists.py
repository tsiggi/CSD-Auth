#
# ΑΣΚΗΣΕΙΣ με Λίστες
#
#
# Λίστα με ψευδοτυχαίους αριθμούς
#
##import random
##
##lista=[]
##for i in range(100):
##    lista.append(random.randint(1,50))
##
####lista = [random.randint(1,50) for i in range(100)]
##
##maxnum = 1; posmax=0
##minnum = 50; posmin=0
##
##place=0
##for k in lista:
##    place+=1
##    if k<minnum:
##        minnum = k
##        posmin=place
##    if k>maxnum:
##        maxnum=k
##        posmax=place
##print('Max: ',maxnum, 'Posmax: ', posmax,' Min: ',minnum, 'Posmin: ',posmin)
##
##print(max(lista), lista.index(max(lista))+1, min(lista), lista.index(min(lista))+1)
##
#
#----------------------------------------------------------------------------------
#
# Φρουτακια 
##
##import random 
##
##lista=[[0 for i in range(3)] for k in range(3)]
##MAXNUM=3
##
##while True:
##    print('\n\n')
##    for i in range(3):
##        for k in range(3):
##            lista[k][i]=random.randint(1,MAXNUM)
##
##    for row in lista:
##        print(row)
##   
##    #check Rows
##    rowWin=0
##    for row in lista:
##        if row[0]==row[1]==row[2]:
##            rowWin+=1
##    print('ΚΕΡΔΗ: ',rowWin)
##
##    if input('Enter to play / "q" to quit)')=='q':
##        break 

#
#----------------------------------------------------------------------------------
#
# Λίστα με αριθμούς χωρίς πολλαπλές εμφανίσεις 
#
##import random
##ORIO=20
##MAXNUM=20
##
##lista = [random.randint(1,ORIO) for i in range(MAXNUM)]
##new_lista=[]
##
##for i in lista:
##    if lista.count(i)==1:
##        new_lista.append(i)
##    else:
##        for j in new_lista:
##            if i==j:break
##        else:
##            new_lista.append(i)
##            
##print(len(new_lista))
##new_lista.sort()
##print(new_lista)

#
#----------------------------------------------------------------------------------
#
# Κληρώσεις Joker 
#       
##        
##import random
##MAXNUM=1000
##
##lista=[[random.randint(1,45) if i<5 else random.randint(1,20) for i in range(6)] for k in range(MAXNUM)]
##
##
####while True:
####    k_num=int(input('Αριθμός κληρωσης (1-100): '))
####    for i in range(5):
####        print(lista[k_num-1][i],'  ',end='')
####    print('Joker: ',lista[k_num-1][5])
####    if input('Enter to continue  /  "q" to quit')=='q':break
##    
##
##while True:
##    userlist = input("Δώσε τη στηλη σου (5+1 αριθμοί χωρισμένοι με κόμμα): ").split(',')
##    klir_num=0
##    
##    for x in lista:
##        klir_num+=1
##        numbers=0
##        joker=0
##
##        #Check Numbers
##        for j in userlist[0:5]:
##            if int(j) in x[0:5]:
##                numbers+=1
##        else:
##            #check Joker
##            if int(userlist[5])==x[5]:
##                joker = 1
##
##        if numbers+joker >=3:
##            print('Κλήρωση: %3d' %klir_num) 
##            print('Επιτυχίες: %3d Αριθμοί &%2d Joker' %(numbers, joker))
##            print('Αριθμοί: ', x[0:5], 'Joker: ',x[5])
##            print()
##
##    if input('Enter to continue  /  "q" to quit')=='q':break












