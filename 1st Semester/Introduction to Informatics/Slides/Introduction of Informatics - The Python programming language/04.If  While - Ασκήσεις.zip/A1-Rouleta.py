#
# Ασκήσεις Α1
# while / for / if
#
#==============================================
#==============================================
# Ρουλέτα
#
import random

while True:
    value = random.randint(0, 36)
    
    if value == 0:
        print('Κερδίζει το 0')
    else:
        # Μικρά - Μεγάλα
        if value <= 18:
            mikmeg = 'Μικρά'
        else:
            mikmeg = 'Μεγάλα'

        # Μονά - Ζυγά
        if value%2 == 0:
            monazyga = 'Ζυγά'
        else:
            monazyga = 'Μονά'
        
        # Κόκκινο - Μαύρο
        if value < 11:
            if value%2 != 0:
                xrwma = 'Κόκκινο'
            else:
                xrwma = 'Μαυρο'
        elif value < 19:
            if value%2 != 0:
                xrwma = 'Μαυρο'
            else:
                xrwma = 'Κόκκινο'        
        elif value < 29:
            if value%2 != 0:
                xrwma = 'Κόκκινο'
            else:
                xrwma = 'Μαυρο'
        else:
            if value%2 != 0:
                xrwma = 'Μαυρο'
            else:
                xrwma = 'Κόκκινο'    

        # Τύπωσε την έξοδο
        print(value, monazyga, mikmeg, xrwma)

    # Μενού επιλογών χρήστη
    if input('Enter / q ') == 'q':
        break
