#
# ΑΣΚΗΣΕΙΣ με ΣΥΝΑΡΤΗΣΕΙΣ
#
#
#----------------------------------------------------------------
#
# (1) Πρώτοι αριθμοί 
#
##import math
##
##def is_prime(number):
##    if number > 1:
##        if number == 2:
##            return True
##        if number % 2 == 0:
##            return False
##        for div in range(3, int(math.sqrt(number) + 1), 2):
##            if number % div == 0: 
##                return False
##        return True
##    return False
##
##def main():
##    while True:
##        num = int(input('Ακέραιος: '))
##        print(is_prime(num))
##
##        if input('Enter to continue,   "q" to quit') == 'q':
##            break
##
##if __name__ == '__main__':
##    main()
##
#
#
#
#----------------------------------------------------------------
#
# (2) Πεζά - Κεφαλαία  
#
##def upper_low(mystr, mode):
##    if mode=='1':
##        def trans(mych):
##            return mych.upper()
##    elif mode == '2':
##        def trans(mych):
##            return mych.lower()
##
##    new_str=''
##    for ch in mystr:
##        new_str += trans(ch)
##    return new_str
##
##
##def main():
##    while True:
##        symb = input('Συμβολοσειρά: ')
##        md = input('Κεφαλαία (1) ή Πεζά (2);')
##        print(upper_low(symb, md))
##
##        if input('Enter to continiue  /  "q" to quit') == 'q':
##            break
##
##if __name__ == '__main__':
##    main()
##


#
#----------------------------------------------------------------
#
# (3) Καλός κωδικός  
#

##def checkPass(password):
##    has_upper = False
##    has_lower = False
##    has_num = False
##    state = 'Απορρίπτεται'
##
##    def checkUpper(x):
##        nonlocal has_upper
##        if x>='A' and x<='Z':
##            has_upper = True
##                    
##    def checkLower(x):
##        nonlocal has_lower
##        if x>='a' and x<='z':
##            has_lower = True
##        
##    def checkNum(x):
##        nonlocal has_num
##        if x>="0" and x<="9":
##            has_num = True
##            
##    for ch in password:
##        if not has_upper:
##            checkUpper(ch)
##        if not has_lower:
##            checkLower(ch)
##        if not has_num:
##            checkNum(ch)
##        if has_upper and has_lower and has_num:
##            if len(password)>=8:
##                state = 'Αποδεκτό'
##            break
##    return state
##
##def main():
##    while True:
##        ps = input('Κωδικός: ')
##        print(checkPass(ps))
##
##        if input('Enter to continue  //  "q" to quit') == 'q':
##            break
#
#----------------------------------------------------------------
#
# (4) ΚΛΑΣΙΚΟΙ ΑΛΓΟΡΙΘΜΟΙ & ΔΟΜΕΣ ΔΕΔΟΜΕΝΩΝ
# http://interactivepython.org/runestone/static/pythonds/index.html

#====================================================================================
#
# ΑΛΓΟΡΙΘΜΟΙ ΑΝΑΖΗΤΗΣΗΣ
#
# Σειριακή Αναζήτηση
# Sequential Search
# http://interactivepython.org/runestone/static/pythonds/SortSearch/TheSequentialSearch.html
#

##def sequentialSearch(alist, item):
##    pos = 0
##    found = False
##
##    while pos < len(alist) and not found:
##        if alist[pos] == item:
##            found = True
##        else:
##            pos = pos+1
##
##    return found
##	
##testlist = [1, 2, 32, 8, 17, 19, 42, 13, 0]
##print(sequentialSearch(testlist, 3))
##print(sequentialSearch(testlist, 13))


#------------------------------------------
# Δυαδική Αναζήτηση
# Binary Search
# http://interactivepython.org/runestone/static/pythonds/SortSearch/TheBinarySearch.html
#
##def binarySearch(alist, item):
##    first = 0
##    last = len(alist)-1
##    found = False
##
##    while first<=last and not found:
##        midpoint = (first + last)//2
##        if alist[midpoint] == item:
##            found = True
##        else:
##            if item < alist[midpoint]:
##                last = midpoint-1
##            else:
##                first = midpoint+1
##
##    return found
##            
##
##testlist = [0, 1, 2, 8, 13, 17, 19, 32, 42,]
##print(binarySearch(testlist, 3))
##print(binarySearch(testlist, 13))


#====================================================================================
#
# ΑΛΓΟΡΙΘΜΟΙ ΤΑΞΙΝΟΜΗΣΗΣ
#
# Ταξινόμηση Φυσαλίδας
# Bubble Sort
# http://interactivepython.org/runestone/static/pythonds/SortSearch/TheBubbleSort.html
#
##def bubbleSort(alist):
##    for passnum in range(len(alist)-1,0,-1):
##        for i in range(passnum):
##            if alist[i]>alist[i+1]:
##                temp = alist[i]
##                alist[i] = alist[i+1]
##                alist[i+1] = temp
##
##alist = [54,26,93,17,77,31,44,55,20]
##bubbleSort(alist)
##print(alist)

#------------------------------------------
# Ταξινόμηση Επιλογής 
# Selection Sort
# http://interactivepython.org/runestone/static/pythonds/SortSearch/TheSelectionSort.html
#
##def selectionSort(alist):
##   for fillslot in range(len(alist)-1,0,-1):
##       positionOfMax=0
##       for location in range(1,fillslot+1):
##           if alist[location]>alist[positionOfMax]:
##               positionOfMax = location
##
##       temp = alist[fillslot]
##       alist[fillslot] = alist[positionOfMax]
##       alist[positionOfMax] = temp
##
##alist = [54,26,93,17,77,31,44,55,20]
##selectionSort(alist)
##print(alist)


#------------------------------------------
# Ταξινόμηση Merge
# Merge Sort
# http://interactivepython.org/runestone/static/pythonds/SortSearch/TheMergeSort.html
#
##def mergeSort(alist):
##    print("Splitting ",alist)
##    if len(alist)>1:
##        mid = len(alist)//2
##        lefthalf = alist[:mid]
##        righthalf = alist[mid:]
##
##        mergeSort(lefthalf)
##        mergeSort(righthalf)
##
##        i=0
##        j=0
##        k=0
##
##        while i < len(lefthalf) and j < len(righthalf):
##            if lefthalf[i] < righthalf[j]:
##                alist[k]=lefthalf[i]
##                i=i+1
##            else:
##                alist[k]=righthalf[j]
##                j=j+1
##            k=k+1
##
##        while i < len(lefthalf):
##            alist[k]=lefthalf[i]
##            i=i+1
##            k=k+1
##
##        while j < len(righthalf):
##            alist[k]=righthalf[j]
##            j=j+1
##            k=k+1
##    print("Merging ",alist)
##    input()
##
##
##alist = [54,26,93,17,77,31,44,55,20]
##mergeSort(alist)
##print(alist)

        
