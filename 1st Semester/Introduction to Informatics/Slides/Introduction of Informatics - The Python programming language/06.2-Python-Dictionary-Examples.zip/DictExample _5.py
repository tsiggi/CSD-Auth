
# Παραδείγματα με ΛΕΞΙΚΟ - Dictionary
#
#=======================================================
#=======================================================
# Παράδειγμα-5
# Google geo_info
# LIST & DICT Παράδειγμα Συνδυασμού

import pprint

geo_info = [{'address_components': [{'name': 'ΛΕΥΚΟΣ ΠΥΡΓΟΣ',
                                     'types': ['point_of_interest', 'establishment']},
                                    {'name': 'Thessaloniki',
                                     'types': ['locality', 'political']},
                                    {'formatted_address': 'ΛΕΥΚΟΣ ΠΥΡΓΟΣ, Thessaloniki 546 21, Greece',
                                     'geometry': {'location': {'lat': 40.6257895, 'lng': 22.9495735},
                                                  'place_id': 'ChIJN4DZEQM5qBQRULmG-uTW4-c',
                                                  'types': ['bus_station',
                                                            'transit_station',
                                                            'point_of_interest',
                                                            'establishment']}}]}]

#pprint.pprint(geo_info)
print(len(geo_info), len(geo_info[0]),
      len(geo_info[0]['address_components']),
      len(geo_info[0]['address_components'][2]),
      len(geo_info[0]['address_components'][2]['geometry']))

print(type(geo_info[0]['address_components'][2]['geometry']))

print(geo_info[0]['address_components'][2]['formatted_address'])
print(geo_info[0]['address_components'][2]['geometry']['location']['lat'])












