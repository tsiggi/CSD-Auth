
# Παραδείγματα με ΛΕΞΙΚΟ - Dictionary
#
#=======================================================
#=======================================================
# Παράδειγμα-4
# Λίστα Λεξικών -- B

import pprint
country={}

country['GR'] = {'Name':'Greece',
                 'Capital':'Athens',
                 'Pop':11}
country['IT'] = {'Name':'Italy',
                 'Capital':'Rome',
                 'Pop':60}
country['SP'] = {'Name':'Spain',
                 'Capital':'Madrid',
                 'Pop':50}

Europe=['' for i in range(3)]

Europe[0]=country['GR']
Europe[1]=country['IT']
Europe[2]=country['SP']

pprint.pprint(Europe)








