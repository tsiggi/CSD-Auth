
# Παραδείγματα με ΛΕΞΙΚΟ - Dictionary
#
#=======================================================
#=======================================================
# Παράδειγμα-1
# Λεξικό με τιμή Λίστα 
# Σχήμα DICT {Code:[CountryName, Capital, Pop]}

country = {}
country['GR'] = ['Greece', 'Athens', 11]
country['IT'] = ['Italia', 'Rome', 60]
country['SP'] = ['Spain', 'Madrid', 50]

for c in country:
    print(c, country[c])

while True:
    epil = input("Κωδικός Χώρας ('q' to Quit): ")
    if epil !='q':
        print(country[epil])
    else:
        break








