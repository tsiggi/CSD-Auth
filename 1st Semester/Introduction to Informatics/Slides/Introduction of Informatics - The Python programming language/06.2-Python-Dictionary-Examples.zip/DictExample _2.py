
# Παραδείγματα με ΛΕΞΙΚΟ - Dictionary
#
#=======================================================
#=======================================================
# Παράδειγμα-2
# Λεξικο με τιμή Λεξικο
# Σχήμα DICT {Code:{CountryName:, Capital:, Pop:]}
# Χρήση pprint

import pprint

country = {}
country['GR'] = {'Name':'Greece',
                 'Capital':'Athens',
                 'Pop':'11 milions'}
country['IT'] = {'Name':'Italy',
                 'Capital':'Rome',
                 'Pop':'60 milions'}
country['SP'] = {'Name':'Spain',
                 'Capital':'Madrid',
                 'Pop':'50 milions'}

for c in country:
    print(c, country[c])

pprint.pprint(country)

while True:
    epil = input("Κωδικός Χώρας ('q' to Quit): ")
    if epil !='q':
        print(country[epil]['Name'])
        key2 = input("Search 'Capital / Pop': ")
        print(country[epil][key2])
    else:
        break








