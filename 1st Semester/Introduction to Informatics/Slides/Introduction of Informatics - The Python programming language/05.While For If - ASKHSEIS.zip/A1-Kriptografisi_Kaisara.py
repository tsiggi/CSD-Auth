#
# Ασκήσεις Α1
# while / for / if
#
#==============================================
#==============================================
 
#==============================================
# Κρυπτογράφηση Καίσαρα
#
#for i in range(913, 938):
#    print(i, ' ',chr(i))

# Α-->913, Ω-->937, όχι χαρακτηρας-->930
#(see https://www.ssec.wisc.edu/~tomw/java/unicode.html)
# ord (από Χαρακτηρα σε Κωδικο)
# chr (από Κωδικο σε Χαρακτηρα)


while True:
    message = input('Μήνυμα (κεφαλαία χωρίς τονισμό): ')
    shift = int(input('Μετατόπιση: '))
    new_message=''

    for ch in message:
        if 'Α'<=ch<='Ω': #Between operator
        #if ch>='Α' and ch<='Ω':
            pos = ord(ch)-ord('Α')
            #print(pos) #for debug
            pos = (pos + shift)%25
            #print(pos) #for debug
            new_char = chr(pos + ord('Α'))
            new_message = new_message + new_char
        else:
            new_message = new_message + ch
    print(new_message)        

    if input('Enter / q ') == 'q':
        break
