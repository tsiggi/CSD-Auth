
import random

# 1) Δημιουργήστε τη λιστα L με 1000 θέσεις με ψευδοτυχαιους αριθμούς μεταξύ 1 και 10
# Χρησιμοποιήστε append() - Εμφανίστε την L στην οθόνη

##TOTAL = 1000
##L = []
##for i in range(TOTAL):
##    L.append(random.randint(1,10))
##print(L)


# 2) Δημιουργήστε τη λίστα L με 1000 θέσεις με ψευδοτυχαίους αριθμούς μεταξύ 1 και 10
# Χρησιμοποιήστε list comprehension - Εμφανίστε την L στην οθόνη 
TOTAL=1000
L = [random.randint(1,10) for i in range(TOTAL)]
##print(L)

# 3) Δημιουργήστε τη λίστα Lstat με 10 θέσεις
# Αποθηκεύστε στην Lstat την συχνότητα εμφανισης καθε αριθμού 1-10 στην L
# Εμφανίστε την Lstat στην οθόνη

Lstat = [0 for i in range(10)]

for i in L:
    Lstat[i-1] += 1
else:
    for k in range(10):
        Lstat[k] = Lstat[k]/TOTAL
    
print(Lstat)

# 4) Γράψτε έναν απλό αλγόριθμο min-max για να βρείτε:  
# Ποιός αριθμός εμφανίζεται με τη Μικρότερη/Μεγαλύτερη πιθανότητα στην Lstat
# Εμφανίστε τις πιθανότητες και τους αντίστοιχους αριθμούς στην οθόνη

minpos = maxpos = 0
for i in range(1,len(Lstat)): 
    if Lstat[i] < Lstat[minpos]: minpos = i  
    if Lstat[i] > Lstat[maxpos]: maxpos = i

print('Μικρότερη: ', Lstat[minpos], minpos+1)
print('Μεγαλύτερη: ', Lstat[maxpos], maxpos+1)    
    
# 5) Υπολογίστε τις ίδιες πιθανότητες όπως παραπάνω με διαφορετικό τρόπο:
# Χρησιμοποιήστε συναρτήσεις και μεθόδους λιστών
# Υπόδειξη: min(), max() & list.index()

print('Μικρότερη: ', min(Lstat), Lstat.index(min(Lstat))+1)
print('Μεγαλύτερη: ', max(Lstat), Lstat.index(max(Lstat))+1)










