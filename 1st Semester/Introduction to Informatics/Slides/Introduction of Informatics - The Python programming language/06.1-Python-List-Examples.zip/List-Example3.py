
# Λίστες λιστών

# 1) Δημιουργήστε με list comprehension μια λίστα L
# παρομοια με πίνακα 3 Χ 3 με '0' σε όλες τις θέσεις.
# Εμφανίστε τη λίστα στην οθόνη χρησιμοποιώντας
# δύο, έναν, ή και κανένα δείκτη   

L = [[0 for k in range(3)] for i in range(3)]

##for row in L:
##    print(row)
##
##for row in L:
##    for x in row:
##        print(x)
##
##for i in range(3):
##    print(L[i])
##
##for i in range(3):
##    for j in range(3):
##        print(L[i][j])


# 2) Δημιουργήστε τη λίστα L με list comprehension
# και με ψευδοτυχαίες τιμές [1,10]. # Στη συνέχεια εμφανίστε τη λίστα με τη μορφή:
# Χ Χ Χ
# Χ Χ Χ
# Χ Χ Χ
# και υπολογίστε τα αθροίσματα στις "σειρές", τις "στήλες" και τις 2 "διαγωνίους" 

import random

L = [[random.randint(1,10) for k in range(3)] for i in range(3)]

##for row in L:
##    print(row)
##
### "Σειρές"
##suma = 0
##for x in L:
##    suma = x[0]+x[1]+x[2]
##    print(suma)
##
### "Στήλες"
##suma = 0
##for x in range(3):
##    suma = L[0][x]+L[1][x]+L[2][x]
##    print(suma)
##
### "Διαγώνιοι"
##sum1 = L[0][0]+L[1][1]+L[2][2]
##sum2 = L[0][2]+L[1][1]+L[2][0]
##print(sum1, sum2)














