#ifndef ARRAY_H
#define ARRAY_H
class Array
{
    protected:
        void swap (int i, int j);
        int *data;
        int size;
    public:
        Array();
        Array(int mysize);
        Array (const Array &o);
        ~Array();
        bool insert (int pos, int key);
        bool get (int pos, int &key) const;
        int getSize() const;
        bool Max(int &);
        int Min();
        int sum();
        bool avg(double &);
        void randomize();
        int search (int key);
        void selectsort();
        void bubblesort();
};
#endif // ARRAY_H
