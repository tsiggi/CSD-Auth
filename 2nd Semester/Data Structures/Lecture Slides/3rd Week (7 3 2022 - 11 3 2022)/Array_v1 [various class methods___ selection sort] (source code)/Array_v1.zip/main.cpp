#include <iostream>
#include "Array.h"

using namespace std;

// If "printArray (Array a)", then the copy constructor will be called!
void printArray (const Array &a)
{
    cout<<"[";
    for (int i=0;i<a.getSize();i++)
    {
        int k;
        if (a.get(i,k))
            cout<<k<<" ";
    }
    cout<<"]"<<endl;
}

int main()
{
    Array bs(10);
    Array ss(10);
    bs.randomize();
    ss.randomize();

    // bubble sort
    cout << "BUBBLE SORT" << endl;
    cout << "Initial array: ";
    printArray(bs);

    bs.bubblesort();

    cout << "Sorted array (bubblesort): ";
    printArray(bs);

    // select sort
    cout << "SELECTION SORT" << endl;
    cout << "Initial array: ";
    printArray(ss);

    ss.bubblesort();

    cout << "Sorted array (selectsort): ";
    printArray(ss);

    return 0;
}
