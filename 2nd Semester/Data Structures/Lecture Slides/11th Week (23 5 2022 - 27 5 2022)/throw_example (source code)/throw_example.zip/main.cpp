#include <cstdlib>
#include <iostream>
#include <string.h>
using namespace std;
int main() {
  char buff[30] = "H glossa C++ se bathos";
  int i, mikos;
  mikos = strlen(buff);
  try {
    cout << "Dose enan arithmo:";
    cin >> i;
    if (i > mikos) {
      throw i;
    } else if (i < 0)
      throw "arnitiki timi";
    else
      cout << buff[i] << endl;
  } catch (int n) {
    cout << "Mi apodekti thesi: " << n << endl;
  } catch (const char *mes) {
    cout << mes << endl;
  }
  return 0;
}
