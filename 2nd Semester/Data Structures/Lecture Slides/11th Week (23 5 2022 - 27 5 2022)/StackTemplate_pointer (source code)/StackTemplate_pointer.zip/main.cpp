#include "Stack.h"
#include <iostream>
using namespace std;

int main() {
  Stack<float> a;

  a.push(3.14);
  a.push(45);
  a.push(0.54);

  while (!a.isEmpty()) {
    cout << a.getTop() << endl;
    a.pop();
  }
  return 0;
}

