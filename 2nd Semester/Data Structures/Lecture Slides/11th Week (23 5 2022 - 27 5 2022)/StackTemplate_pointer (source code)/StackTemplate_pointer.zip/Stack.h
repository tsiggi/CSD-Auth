
template <class X> class Stack {
private:
  X *data;
  int size;
  void resize(int);

public:
  Stack();
  void push(const X &);
  void pop();
  X getTop();
  void clear();
  bool isEmpty();
};

template <class X> Stack<X>::Stack() {
  size = 0;
  data = nullptr;
}

template <class X> void Stack<X>::resize(int nsize) {
  X *temp;
  temp = new X[nsize];
  for (int i = 0; i < size; i++)
    temp[i] = data[i];
  delete[] data;
  data = temp;
  size = nsize;
}

template <class X> void Stack<X>::pop() { resize(size - 1); }
template <class X> X Stack<X>::getTop() { return data[size - 1]; }
template <class X> void Stack<X>::clear() {
  size = 0;
  delete[] data;
  data = nullptr;
}
template <class X> void Stack<X>::push(const X &elm) {
  resize(size + 1);
  data[size - 1] = elm;
}
template <class X> bool Stack<X>::isEmpty() { return size == 0; }
