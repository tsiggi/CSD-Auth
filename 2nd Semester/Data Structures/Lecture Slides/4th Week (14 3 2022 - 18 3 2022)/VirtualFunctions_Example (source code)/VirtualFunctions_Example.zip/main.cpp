#include <iostream>
using namespace std;

class Account {
protected:
  double balance;

public:
  Account(double d) { balance = d; }
  virtual void PrintBalance() { // try to remove the 'virtual' keyword and run it
    cout << "Error. Balance not available for base type." << endl;
  }
};

class CheckingAccount : public Account {
public:
  CheckingAccount(double d) : Account(d) {}
  void PrintBalance() {
    cout << "Checking account balance: " << balance << endl;
  }
};

class SavingsAccount : public Account {
public:
  SavingsAccount(double d) : Account(d) {}
  void PrintBalance() {
    cout << "Savings account balance: " << balance << endl;
  }
};

int main() {
  Account *accounts[2];
  accounts[0] = new CheckingAccount(100.00);
  accounts[1] = new CheckingAccount(1000.00);
  for(int i = 0; i<2; ++i) {
    accounts[i] -> PrintBalance();
  }
  
}