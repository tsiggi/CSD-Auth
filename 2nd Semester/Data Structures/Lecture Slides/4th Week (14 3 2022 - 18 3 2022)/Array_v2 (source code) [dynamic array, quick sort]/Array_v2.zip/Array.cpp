#include "Array.h"
#include <iostream>
#include <cstdlib>
#include <time.h>
using namespace std;

Array::Array()
{
    size = 0;
}

Array::Array(int mysize)
{
    size = mysize;
    data = new int[size + 1];
    for (int i = 0; i < size; i++)
        data[i] = 0;
}

Array::~Array()
{
    if (size > 0)
        delete[] data;
}

Array::Array(const Array &o)
{
    cout << "COPY CONSTRUCTOR" << endl;
    size = o.size;
    data = new int[size];
    for (int i = 0; i < size; i++)
        data[i] = o.data[i];
}

bool Array::insert(int pos, int key)
{
    cout << "Inserting " << key << " in position " << pos;
    if (pos < size)
    {
        data[pos] = key;
        cout << " Done." << endl;
        return true;
    }
    else
        cout << " Fail." << endl;
        return false;
}

bool Array::get(int pos, int &key) const
{
    if (pos < size)
    {
        key = data[pos];
        return true;
    }
    else
        return false;
}

int Array::getSize() const
{
    return size;
}

bool Array::Max(int &key)
{
    if (size == 0)
        return false;
    int mymax = data[0];
    for (int i = 1; i < size; i++)
        if (data[i] > mymax)
            mymax = data[i];
    key = mymax;
    return true;
}

int Array::Min()
{
    if (size == 0)
        return -999;
    int mymin = data[0];
    for (int i = 1; i < size; i++)
        if (data[i] < mymin)
            mymin = data[i];
    return mymin;
}

int Array::sum()
{
    int sum = 0;
    for (int i = 0; i < size; i++)
    {
        sum += data[i];
    }
    return sum;
}

bool Array::avg(double &v)
{
    if (!size)
        return false;
    v = (double)sum() / size;
    return true;
}

void Array::randomize()
{
    srand(time(NULL));
    for (int i = 0; i < size; i++)
    {
        data[i] = (rand() % 100) + 1;
    }
}

int Array::search(int key)
{
    int i = 0;
    while (i < size && data[i] != key)
        i++;
    if (data[i] == key)
        return i;
    else
        return -1;
}

void Array::swap(int i, int j)
{
    int temp = data[i];
    data[i] = data[j];
    data[j] = temp;
}

void Array::bubblesort()
{
    int flag = 1;
    for (int i = 0; flag && i < size; i++)
    {
        flag = 0;
        for (int j = size - 1; j > i; j--)
            if (data[j] < data[j - 1])
            {
                swap(j, j - 1);
                flag = 1;
            }
    }
}

void Array::selectsort()
{
    int minpos;
    for (int i = 0; i < size; i++)
    {
        // Find the minimum element in unsorted array
        minpos = i;

        for (int j = size - 1; j > i; j--)
        {
            if (data[j] < data[minpos])
                minpos = j;
        }
        // Swap the found minimum element with the first element of the "subarray"
        swap(minpos, i);
    }
}

// v2
int Array::partition(int left, int right, int pivotIndex)
{
    int pivot = data[pivotIndex];
    swap(pivotIndex, right);
    int storeIndex = left;
    for (int i = left; i < right; i++)
    {
        if (data[i] <= pivot)
        {
            swap(i, storeIndex);
            storeIndex++;
        }
    }
    swap(storeIndex, right);
    return storeIndex;
}

void Array::quicksort(int left, int right)
{
    if (left < right)
    {
        int pivotIndex = left + (right - left) / 2;
        pivotIndex = partition(left, right, pivotIndex);
        quicksort(left, pivotIndex - 1);
        quicksort(pivotIndex + 1, right);
    }
}
