#ifndef DYNAMICARRAY_H
#define DYNAMICARRAY_H

#include "Array.h"

class DynamicArray : public Array
{
public:
    DynamicArray(int size);
    bool insert(int pos, int key);
};

#endif // DYNAMICARRAY_H


