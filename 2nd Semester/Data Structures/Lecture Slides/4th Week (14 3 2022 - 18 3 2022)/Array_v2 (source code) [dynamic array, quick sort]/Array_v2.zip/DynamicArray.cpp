#include "DynamicArray.h"
#include <iostream>
#include <cstring>

using namespace std;

DynamicArray::DynamicArray(int size) : Array(size)
{
}

bool DynamicArray::insert(int pos, int key)
{
    if (pos >= size)
    {
        cout << "Resizing array... "
             << "Current size: " << size;
        int *temp;
        temp = new int[pos + 1];
        memcpy(temp, data, size * sizeof(data[0]));
        size = pos + 1;
        delete[] data;
        data = temp;
        std::cout << " New size: " << size << endl;
    }
    return Array::insert(pos, key);
}
