#include <iostream>
#include "Array.h"
#include "DynamicArray.h"

using namespace std;

// If we define it as "printArray (Array a)", then the copy constructor will be called!
void printArray(const Array &a)
{
    cout << "[";
    for (int i = 0; i < a.getSize(); i++)
    {
        int k;
        if (a.get(i, k))
            cout << k;
        if(i != a.getSize() - 1)
            cout << " " ;
    }
    cout << "]" << endl;
}

int main()
{
    Array bs(10);
    Array ss(10);
    Array qs(10);
    bs.randomize();
    ss.randomize();
    qs.randomize();

    // bubble sort
    cout << "BUBBLE SORT" << endl;
    cout << "Initial array: ";
    printArray(bs);

    bs.bubblesort();

    cout << "Sorted array (bubblesort): ";
    printArray(bs);

    // select sort
    cout << "SELECTION SORT" << endl;
    cout << "Initial array: ";
    printArray(ss);

    ss.bubblesort();

    cout << "Sorted array (selectsort): ";
    printArray(ss);

    // v2
    // quick sort
    cout << "QUICK SORT" << endl;
    cout << "Initial array: ";
    printArray(qs);

    qs.quicksort(0, 9);

    cout << "Sorted array (quicksort): ";
    printArray(qs);

    // DYNAMIC ARRAY
    cout << "DYNAMIC ARRAY" << endl;
    DynamicArray da(1);
    da.insert(0, 100);
    da.insert(5, 200);
    printArray(da);

    return 0;
}
