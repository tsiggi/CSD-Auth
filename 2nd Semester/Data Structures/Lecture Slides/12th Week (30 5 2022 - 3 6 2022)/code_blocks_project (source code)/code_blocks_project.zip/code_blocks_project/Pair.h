#ifndef STR_H
#define STR_H

#include <iostream>

using namespace std;

template <typename X>
class Pair
{
private:
    X first, second;
public:
    Pair();
    Pair(X, X);
    void setFirst (X value) {first = value;}
    void setSecond (X value) {second = value;}
    X getFirst() const {return first;}
    X getSecond() const  {return second;}
    void swap();

    //template <typename Y>
    //friend ostream & operator<< (ostream &o, const Pair<Y> &v);
};
template <typename X>
Pair<X>::Pair()
{
}
template <typename X>
Pair<X>::Pair(X a, X b)
{
    first  = a;
    second = b;
}
template <typename X>
void Pair<X>::swap()
{
    X temp;
    temp = first;
    first = second;
    second = temp;
}

template <typename X>
ostream & operator<< (ostream &o, const Pair<X> &v)
{
    o<<v.getFirst()<<","<<v.getSecond();
    return o;
}

#endif
