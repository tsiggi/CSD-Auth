#include "Student.h"
#include <fstream>
#include <iostream>

using namespace std;

int main() {

  char name[50];
  int semester;

  cout << "Give name: " << endl;
  cin >> name;
  cout << "Give semester" << endl;
  cin >> semester;
  Student s1(name, semester);

  cout << "Give name: " << endl;
  cin >> name;
  cout << "Give semester" << endl;
  cin >> semester;
  Student s2(name, semester);

  //s1.print();
  //s2.print();

  // save
  ofstream out;
  out.open("student.dat", ios::binary);
  if (out) {
    out.write((char *)&s1, sizeof(Student));
    out.write((char *)&s2, sizeof(Student));
    out.close();
  }

  // read
  ifstream in;
  Student s;
  in.open("student.dat", ios::binary);
  while (!in.eof()) {
    in.read((char *)&s, sizeof(Student));
    s.print();
  }
  in.close();
}