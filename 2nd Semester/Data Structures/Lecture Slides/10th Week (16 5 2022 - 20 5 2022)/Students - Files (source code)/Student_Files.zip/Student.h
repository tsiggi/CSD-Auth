#ifndef STUDENT_H
#define STUDENT_H

#include "string.h"

class Student {
private:
  char name[50];
  int semester;

public:
  Student(char name[], int semester);
  Student(){};
  char *getName();
  int getSemester();
  void print();
};

#endif