#include "Student.h"
#include <iostream>

using namespace std;

Student::Student(char name[], int semester) {
  strcpy(this->name, name);
  this->semester = semester;
}

char *Student::getName() { return this->name; }

int Student::getSemester() { return this->semester; }

void Student::print() { cout << this->name << " " << this->semester << endl; }