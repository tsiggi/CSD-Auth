#ifndef ITEM_H
#define ITEM_H

class Item {
public:
  int a;
  Item(int a);
};

#endif 
