#include "Item.h"

Item::Item(int a) { this->a = a; }
