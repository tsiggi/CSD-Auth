#ifndef BAG_H
#define BAG_H

#include "Item.h"

class Bag {
public:
  Item *items[5];
  Bag();
};

#endif 