#include "Bag.h"
#include <stdio.h>

Bag::Bag() {
   for (int i = 0; i < 5; i++) {
     items[i] = NULL;
   }
}
