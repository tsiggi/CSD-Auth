#include "Bag.h"
#include <iostream>
#include <stdlib.h>

using namespace std;

int main(int argc, char const *argv[]) {
  Bag b;

  // this generates an error, as we are trying to access a member variable from a null pointer
  // for (int i = 0; i < 5; i++) {
  //   cout << b.items[i]->a << endl;
  // }

  b.items[2] = new Item(5);

  for (int i = 0; i < 5; i++) {
    if (b.items[i] != NULL) {
      cout << b.items[i]->a << endl;
    }
  }

  cout << "done" << endl;

  return 0;

}
