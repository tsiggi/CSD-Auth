#include <fstream>
#include <iostream>
#include <string>

using namespace std;


// see here https://stackoverflow.com/questions/62893333/writing-to-ofstream-using-iosate-overwrites-existing-file
int main() {
  ofstream f;
  //f.open("overwrite.txt", ios::in | ios::out); //this also works, we meed tje ios::in in order not to truncate the file
  f.open("overwrite.txt", ios::ate | ios::in); // we need the ios::in in order not to truncate the file
  cout << f.tellp();
  if (f.is_open()) {
    f.seekp(11);
    cout << f.tellp();
    string g = "GEORGE";
    f << g;
    f.close();
  } else {
    cerr << "Could not open file" << endl;
  }
  cout << endl;
  return 0;
}
