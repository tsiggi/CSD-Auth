#include <fstream>
#include <iostream>
#include <string>

using namespace std;

#define BUFF_SIZE 30
int main() {
  ofstream f;
  string data;
  f.open("data_write_string.txt");
  if (f.is_open())
  {
    data = "hello";
    f << data;
    f.close();
  } else {
    cerr << "Could not open file" << endl;
  }
  cout << endl;
  return 0;
}
