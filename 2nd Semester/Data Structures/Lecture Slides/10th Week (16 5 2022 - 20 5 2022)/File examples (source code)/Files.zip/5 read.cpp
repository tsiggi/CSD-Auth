#include <fstream>
#include <iostream>
using namespace std;

int main() {
  ifstream f; // Δηλώνουμε ένα ρεύμα εισόδου f
  char s[30];
  int age;
  f.open("data.txt", ios::in);
  // Άνοιγμα του "data.txt" για ανάγνωση
  if (f.is_open()) // Έλεγχος επιτυχίας ανοίγματος
  {
    f >> s >> age;                 // Διαβάζουμε τα δεδομένα
    cout << "Name: " << s << endl; // Τυπώνουμε τα δεδομένα
    cout << "Age: " << age << endl; // Τυπώνουμε τα δεδομένα
    f.close();                      // Κλείσιμο αρχείου
  } else {
    cerr << "Could not open file" << endl;
  }
  return 0;
}
