#include <fstream>
#include <iostream>
#include <string>

using namespace std;

#define BUFF_SIZE 30
int main() {
  ifstream f;
  string line;
  f.open("data_getline.txt");
  if (f.is_open())
  {
    while(std::getline(f, line, ' ')){
      cout << line << endl;
    }
    f.close();
  } else {
    cerr << "Could not open file" << endl;
  }
  cout << endl;
  return 0;
}
