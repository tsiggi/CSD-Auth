#include <fstream>
#include <iostream>
using namespace std;

class Date {
public:
  int day, month, year;
};

int main() {
  Date birthdate;
  birthdate.day = 10;
  birthdate.month = 5;
  birthdate.year = 1977;
  ofstream f; // Δηλώνουμε ένα ρεύμα εξόδου f
  f.open("a.txt", ios::out); // Άνοιγμα του "a.txt" για εγγραφή
  if (f.is_open()) // Έλεγχος επιτυχίας ανοίγματος
  {
    f << birthdate.day << " " << birthdate.month << " " << birthdate.year
      << endl;
    f.close(); // Κλείσιμο αρχείου
  }
  return 0;
}
