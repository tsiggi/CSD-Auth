#include <fstream>
#include <iostream>
using namespace std;

int main() {
  ofstream f; // Δηλώνουμε ένα ρεύμα εξόδου f
  f.open("a.txt"); // Άνοιγμα του "a.txt" για εγγραφή
  if (!f.is_open()) // Έλεγχος επιτυχίας ανοίγματος
  {
    cerr << "Could not open file" << endl;
  } else {
    cout << "File opened succesfully" << endl;
    f << "Hello world2" << endl; // Εγγραφή κειμένου στο f
    f.close();                  // Κλείσιμο αρχείου
  }
  return 0;
}
