#include <fstream>
#include <iostream>
using namespace std;

class date {
public:
  int day;
  int month;
  int year;
};
ostream &operator<<(ostream &o, date d) {
  o << d.day << " " << d.month << " " << d.year;
  return o;
}
istream &operator>>(istream &i, date &d) {
  i >> d.day >> d.month >> d.year;
  return i;
}
int main() {
  date birthdate;
  cin >> birthdate;

  ofstream f; // Δηλώνουμε ένα ρεύμα εξόδου f
  f.open("a.txt"); // Άνοιγμα του "a.txt" για εγγραφή
  if (f.is_open()) // Έλεγχος επιτυχίας ανοίγματος
  {
    f << birthdate;
    f.close(); // Κλείσιμο αρχείου
  }

  return 0;
}
