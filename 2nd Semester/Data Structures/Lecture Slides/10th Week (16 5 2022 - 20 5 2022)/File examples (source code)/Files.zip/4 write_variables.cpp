#include <fstream>
#include <iostream>
using namespace std;

int main()
{
   ofstream f; // Δηλώνουμε ένα ρεύμα εξόδου f
   char s[30];
   int age;
   f.open("data.txt",ios::out); // Άνοιγμα του "data.txt" για εγγραφή
   if (f.is_open()) // Έλεγχος επιτυχίας ανοίγματος
   {
       cout<<"What is your name: ";
       cin>>s;
       cout<<"How old are you: ";
       cin>>age;
       f<<s<<" "<<age<<endl; // Γράφουμε τα δεδομένα
       f.close(); // Κλείσιμο αρχείου
   }
   else
       cerr<<"Could not open file"<<endl;
   return 0;
}
