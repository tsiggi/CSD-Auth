#include <fstream>
#include <iostream>

using namespace std;

#define BUFF_SIZE 30
int main() {
  ifstream f;
  char s[30];
  f.open("data_getline.txt");
  if (f.is_open())
  {
    while(f.getline(s, BUFF_SIZE, ' ')){
      cout << s;
    }
    f.close();
  } else {
    cerr << "Could not open file" << endl;
  }
  cout << endl;
  return 0;
}
