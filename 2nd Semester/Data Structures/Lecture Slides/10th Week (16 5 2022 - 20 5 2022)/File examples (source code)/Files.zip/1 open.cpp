#include <fstream>
#include <iostream>
using namespace std;

int main() {
  ifstream f; // Δηλώνουμε ένα ρεύμα εισόδου f
  f.open("a.txt"); // Προσπαθούμε να ανοίξουμε το αρχείο "a.txt"
  if (!f.is_open()) // Η is_open() επιστρέφει true αν το αρχείο είναι ανοικτό
  {
    cerr << "Could not open file" << endl;
  } else
    cout << "File opened succesfully" << endl;
  f.close(); // Κλείνουμε το αρχείο

  return 0;
}