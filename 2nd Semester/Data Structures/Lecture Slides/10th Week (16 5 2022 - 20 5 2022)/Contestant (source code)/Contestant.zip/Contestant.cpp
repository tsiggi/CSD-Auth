#include "Contestant.h"
#include <iostream>
using namespace std;

istream &operator>>(istream &i, Contestant &obj) {
  i >> obj.name >> obj.age >> obj.ratings;
  return i;
}
