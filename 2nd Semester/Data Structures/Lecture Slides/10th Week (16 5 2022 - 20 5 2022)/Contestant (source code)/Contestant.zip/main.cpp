#include "Contestant.h"
#include <fstream>
#include <iostream>
#include <string.h>

using namespace std;


int main() {
  ifstream f;
  f.open("data.txt", ios::in);

  Contestant obj;
  int max = 0;
  char Highest_rated[30];
  while (!f.eof()) {
    f >> obj;
    if (obj.ratings > max) {
      max = obj.ratings;
      strcpy(Highest_rated, obj.name);
    }
  }

  cout << Highest_rated << endl;
  return 0;
}

