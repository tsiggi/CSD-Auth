#ifndef CONTESTANT_H
#define CONTESTANT_H

#include <iostream>

using namespace std;

class Contestant {
public:
  char name[30];
  int age, ratings;
};

istream &operator>>(istream &i, Contestant &d);

#endif