class BinarySearch
{
public:
    int search(int data[], int first, int last, int key);
};
