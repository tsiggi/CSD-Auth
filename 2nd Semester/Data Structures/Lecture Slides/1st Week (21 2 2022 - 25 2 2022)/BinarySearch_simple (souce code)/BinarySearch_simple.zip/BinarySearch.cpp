#include "BinarySearch.h"
#include <iostream>

using namespace std;

int BinarySearch::search(int data[], int first, int last, int key)
{
    int mid;
    cout << "first is: " << first <<", last is: " << last;
    if (first <= last)
    {
        mid = (first + last) / 2;
        cout << ", mid is: " << mid << endl;
        if (key < data[mid])
            return search(data, first, mid - 1, key);
        else if (key > data[mid])
            return search(data, mid + 1, last, key);
        else
            return mid;
    }
    else
        return -1;
}

