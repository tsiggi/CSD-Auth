#include <iostream>
#include "BinarySearch.h"

using namespace std;

int main(int argc, char const *argv[])
{
    int key = atoi(argv[1]);

    cout << "**Will search for: " << key << "**" << endl;

    int data[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    BinarySearch bs;

    int pos = bs.search(data, 0, 9, key);

    if(pos == -1)
        cout << endl << "Key not found...";
    else
        cout << "Position: " << pos << endl;

    return 0;
}
