#include "Set.h"
#include <iostream>

using namespace std;

int main() {
  Set A, B, C, D;
  A = A + 'k' + 'a' + 'b' + 'a';
  A.showSet();
  B = B + 'd' + 'b' + 'c';
  B.showSet();
  C = A + B;
  D = A - B;
  C.showSet();
  D.showSet();
  system("pause");
}
