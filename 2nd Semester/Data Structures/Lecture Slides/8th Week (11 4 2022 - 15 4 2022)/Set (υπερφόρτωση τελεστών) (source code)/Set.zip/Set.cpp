#include "Set.h"
#include <iostream>

using namespace std;

Set::Set() { len = 0; }

int Set::getLength() { return len; }

int Set::find(char k) {
  int i;
  for (i = 0; i < len; i++) {
    if (members[i] == k)
      return i;
  }
  return -1;
}

void Set::showSet() {
  int i;
  cout << "{";
  for (i = 0; i < len; i++)
    cout << members[i] << " ";
  cout << "}" << endl;
}

bool Set::isMember(char k) {
  if (find(k) == -1)
    return false;
  else
    return true;
}

Set Set::operator+(char k) {
  Set newSet;
  if (len == 50)
    return *this;
  newSet = *this;
  if (find(k) == -1) {
    newSet.members[len] = k;
    newSet.len++;
  }
  return newSet;
}

Set Set::operator-(char k) {
  Set newSet;
  int i, j;
  j = find(k);
  for (i = 0; i < len; i++)
    if (i != j)
      newSet = newSet + members[i];
  return newSet;
}

Set Set::operator+(Set A) {
  Set newSet = *this;
  int i;
  for (i = 0; i < A.len; i++)
    newSet = newSet + A.members[i];
  return newSet;
}

Set Set::operator-(Set A) {
  Set newSet = *this;
  int i;
  for (i = 0; i < A.len; i++)
    newSet = newSet - A.members[i];
  return newSet;
}
