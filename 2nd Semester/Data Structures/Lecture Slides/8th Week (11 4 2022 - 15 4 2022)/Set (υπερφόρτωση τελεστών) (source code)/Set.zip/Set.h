class Set {
private:
  int len;
  char members[50];
  int find(char k);

public:
  Set();
  int getLength();
  void showSet();
  bool isMember(char k);
  Set operator+(char k);
  Set operator-(char k);
  Set operator+(Set A);
  Set operator-(Set A);
};
