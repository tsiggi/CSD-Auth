#include "Queue.h"
#include <iostream>

using namespace std;

Queue::Queue() {
  size = 5;
  head = 0;
  tail = -1;
  N = 0;
  data = new int[size];
}

Queue::Queue(int size) {
  this->size = size;
  head = 0;
  tail = -1;
  N = 0;
  data = new int[size];
}

Queue::Queue(const Queue &old) {
  size = old.size;
  head = old.head;
  tail = old.tail;
  N = old.N;
  data = new int[size];
  for (int i = 0; i < size; i++)
    data[i] = old.data[i];
}

Queue::~Queue() { delete[] data; }

bool Queue::Enqueue(int element) {
  if (size == N) {
    return false; // Queue full
  }
  tail++;
  if (tail == size)
    tail = 0;
  data[tail] = element;
  N++;
  return true; // completed normally
}

bool Queue::Dequeue(int &element) {
  if (size == 0) {
    return false; // Queue empty
  }
  element = data[head];
  N--;
  head++;
  if (head == size)
    head = 0;
  return true; // completed normally
}

bool Queue::isEmpty() {
  if (N == 0) {
    return true;
  }
  return false;
}
