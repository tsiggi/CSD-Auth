class Queue {
private:
  int size;       // Μέγεθος πίνακα
  int N;          // πλήθος στοιχείων
  int head, tail; // Θέσεις 1ου και Νου στοιχείου
  int *data;      // Πίνακας δεδομένων
public:
  bool Dequeue(int &element);
  bool Enqueue(int element);
  bool isEmpty();
  Queue();
  Queue(int size);
  Queue(const Queue &other);
  ~Queue();
};
