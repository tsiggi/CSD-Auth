#include "Queue.h"
#include <iostream>

using namespace std;

void printQueue(Queue q) {
  while (!q.isEmpty()) {
    int element;
    q.Dequeue(element);
    cout << element << " ";
  }
  cout << endl;
}

int main(int argc, char const *argv[]) {
  Queue q, q2(q);


  q.Enqueue(1);
  q.Enqueue(2);
  q.Enqueue(3);
  q.Enqueue(4);
  q.Enqueue(5);
  q.Enqueue(6);
  printQueue(q);

  int element;
  q.Dequeue(element);
  cout << "Dequeue: " << element << endl;
  q.Dequeue(element);
  cout << "Dequeue: " << element << endl;
  q.Dequeue(element);
  cout << "Dequeue: " << element << endl;

  return 0;
}
