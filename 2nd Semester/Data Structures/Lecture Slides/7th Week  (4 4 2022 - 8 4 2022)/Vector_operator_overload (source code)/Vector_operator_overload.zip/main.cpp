#include "vector.h"
#include <iostream>
using namespace std;

int main() {

  vector2d b, c, d;
  vector2d a(-5, -3, (char *)"babis");

  cout << a.angleToDegrees() << endl;
  a.printtoStdOut();
  b = a;
  a.setLabel((char *)"Maria");
  a.setY(4.3);
  a.setX(7.2);

  cout << "b: ";
  b.printtoStdOut();
  a.printtoStdOut();

  d = a + b;
  c = c;

  d.printtoStdOut();

  vector2d n1(1, 5, (char *)"a");
  vector2d n2(3, 3, (char *)"b");
  vector2d n3;

  n3 = n1 += n2;

  cout << endl;
  n1.printtoStdOut();
  cout << endl;
  n2.printtoStdOut();
  cout << endl;
  n3.printtoStdOut();

  vector2d &n4 = 1.0 * n3;

  if (n4 < n3)
    cout << "n4 is smaller than n3" << endl;
  else if (n4 > n3)
    cout << "n3 is  smaller than n4" << endl;
  else
    cout << "n3 is equal to n4" << endl;

  //    ostream

  cin >> n4;

  cout << n4 << endl << n3 << endl;

  //    n4.printtoStdOut();

  //    d += a;
}