#ifndef vector2d_h
#define vector2d_h

#include <iostream>
using namespace std;

class vector2d {
private:
  double x;
  double y;
  char *label;

public:
  vector2d();
  vector2d(double, double, char *);
  vector2d(const vector2d &);
  ~vector2d();
  void setX(double);
  void setY(double);
  void setLabel(char *);
  char *getLabel();
  double getX() const;
  double getY() const;
  double magnitude() const;
  double angle();
  double angleToDegrees();
  vector2d operator=(const vector2d &);

  vector2d &operator+=(const vector2d &);
  void printtoStdOut();
  friend vector2d &operator*(const vector2d &, double);
  friend vector2d &operator*(double, const vector2d &);
  friend istream &operator>>(istream &, vector2d &);
};
vector2d operator+(const vector2d &, const vector2d &);
bool operator<(const vector2d &, const vector2d &);
bool operator>(const vector2d &, const vector2d &);
bool operator==(const vector2d &, const vector2d &);
ostream &operator<<(ostream &, vector2d &);

#endif
