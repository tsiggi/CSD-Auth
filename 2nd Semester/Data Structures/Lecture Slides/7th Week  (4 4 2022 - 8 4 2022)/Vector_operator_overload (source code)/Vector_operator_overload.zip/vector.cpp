#include "vector.h"
#include <cmath>
#include <cstring>
#include <iostream>
using namespace std;

vector2d::vector2d() {
  x = y = 0;
  label = nullptr;
}

vector2d::vector2d(double x, double y, char *l) {
  this->x = x;
  this->y = y;
  label = new char[strlen(l) + 1];
  strcpy(label, l);
}
vector2d::vector2d(const vector2d &other) {
  this->x = other.x;
  this->y = other.y;
  if (other.label == nullptr) {
    label = nullptr;
  } else {
    label = new char[strlen(other.label) + 1];
    strcpy(label, other.label);
  }
}

vector2d::~vector2d() {
  delete[] label;
  label = nullptr;
}

void vector2d::setX(double x) { this->x = x; }
void vector2d::setY(double x) { y = x; }
void vector2d::setLabel(char *s) {
  delete[] label;
  label = new char[strlen(s) + 1];
  strcpy(label, s);
}
char *vector2d::getLabel() { return label; }
double vector2d::getX() const { return x; }
double vector2d::getY() const { return y; }
double vector2d::magnitude() const { return sqrt(x * x + y * y); }
double vector2d::angle() { return atan2(y, x); }
double vector2d::angleToDegrees() { return atan2(y, x) * 180 / M_PI; }

vector2d vector2d::operator=(const vector2d &other) {
  if (this == &other)
    return *this;

  delete[] label;
  this->x = other.x;
  this->y = other.y;

  if (other.label == nullptr) {
    label = nullptr;
  } else {
    label = new char[strlen(other.label) + 1];
    strcpy(label, other.label);
  }
  return *this;
}

void vector2d::printtoStdOut() {
  if (label != nullptr)
    cout << getLabel() << ", ";
  cout << getX() << "," << getY() << endl;
}

vector2d operator+(const vector2d &one, const vector2d &two) {
  vector2d sum;

  //    sum.setLabel("df");

  sum.setX(one.getX() + two.getX());
  sum.setY(one.getY() + two.getY());

  return sum;
}

vector2d &vector2d::operator+=(const vector2d &other) {
  this->x += other.x;
  this->y += other.y;
  return *this;
}

vector2d &operator*(const vector2d &v, double f) {
  vector2d *r;
  r = new vector2d();

  r->setX(v.getX() * f);

  r->x = v.x * f;
  r->y = v.y * f;
  r->setLabel((char *)"multi5");
  return *r;
}

vector2d &operator*(double f, const vector2d &v) { return v * f; }

bool operator<(const vector2d &a, const vector2d &b) {
  return a.magnitude() < b.magnitude();
}

bool operator>(const vector2d &a, const vector2d &b) {
  return b < a;
  //    return a.magnitude()>b.magnitude();
}

bool operator==(const vector2d &a, const vector2d &b) {
  return a.getX() == b.getX() && a.getY() == b.getY();
}

ostream &operator<<(ostream &o, vector2d &v) {
  o << v.getLabel() << " " << v.getX() << " " << v.getY();
  return o;
}

istream &operator>>(istream &i, vector2d &v) {

  char s[100];

  i >> s;
  v.setLabel(s);

  double t;

  i >> t;
  v.setX(t);
  i >> t;
  v.setY(t);

  i >> v.x >> v.y;
  return i;
}
