#ifndef STACK_H
#define STACK_H

#define RESIZE 5

class Stack
{
private:
  int size;  // Μέγεθος πίνακα
  int pos;   // 1η ελεύθερη θέση
  int *data; // Πίνακας δεδομένων
public:
  bool pop(int &element);
  bool push(int element);
  bool isEmpty();
  void resize(int n);  // Αύξηση μεγέθους κατά n θέσεις
  void print();
  Stack();             //Κενός Κατασκευαστής
  Stack(int n);        //Κατασκευαστής με Συγκεκριμένο Μέγεθος Στοίβας
  Stack(Stack &other); //Κατασκευαστής Αντίγραφου
  ~Stack();            //Καταστροφέας
};
#endif // STACK_H
