#include "Stack.h"
#include <iostream>

using namespace std;

Stack::Stack()
{
    size = 10;
    pos = 0;
    data = new int[size];
}

Stack::Stack(int n)
{
    size = n;
    pos = 0;
    data = new int[size];
}

Stack::Stack(Stack &other)
{
    size = other.size;
    pos = other.pos;
    data = new int[size];
    for (int i = 0; i < size; i++)
        data[i] = other.data[i];
}

Stack::~Stack()
{
    delete[] data;
}

bool Stack::isEmpty()
{
    return (pos == 0);
}

bool Stack::pop(int &element)
{
    if (isEmpty())
        return false; // Stack empty
    pos--;
    element = data[pos];
    return true; // completed normally
}

bool Stack::push(int element)
{
    cout << "Pushing " << element << endl;
    if (pos == size)
    {
        cout << "Max size reached: " << size << endl;
        resize(RESIZE);
    }
    data[pos] = element;
    pos++;
    return true; // completed normally
}

void Stack::resize(int n)
{
    cout << "Resizing... ";
    int *temp;
    temp = new int[size + n];
    for (int i = 0; i < size; i++)
        temp[i] = data[i];
    delete[] data;
    data = temp;
    size = size + n;
    cout << "Done. New size: " << size << endl;
}

void Stack::print()
{
    if (isEmpty())
    {
        cout << "Stack is empty!" << endl;
        return;
    }
    cout << "----" << endl;
    for (int i = pos - 1; i >= 0; i--)
        cout << data[i] << endl;
    cout << "----" << endl;
}
