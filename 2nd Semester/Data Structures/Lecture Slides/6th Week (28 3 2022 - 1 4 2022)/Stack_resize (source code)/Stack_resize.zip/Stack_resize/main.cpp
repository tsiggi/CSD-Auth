#include <iostream>
#include "Stack.h"
using namespace std;

int main()
{
    Stack *s = new Stack(1);
    int choice = 1;
    int element;
    while (choice != 0)
    {
        cout << "1: Push, 2: Pop, 0: Exit: ";
        cin >> choice;
        if (choice == 1)
        {
            cout << "Insert the number: ";
            cin >> element;
            s->push(element);
        }
        else if (choice == 2)
        {
            int popped;
            if (s->pop(popped))
                cout << "Popped element: " << popped << endl;
        }
        s->print();
    }
}