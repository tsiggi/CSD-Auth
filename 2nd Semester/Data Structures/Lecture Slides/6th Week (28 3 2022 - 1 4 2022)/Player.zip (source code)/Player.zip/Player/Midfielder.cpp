#include "Midfielder.h"

Midfielder::Midfielder(char *n, int a, int h, double w, int p, bool i, int s,
                       int g, int ap, int pa, int at, int t)
    : FieldPlayer(n, a, h, w, p, i, s, g, ap, p, at, t) {}

double Midfielder::getGrade() {
  double gr = FieldPlayer::getGrade();
  gr += getDefending();
  gr += 2.5 * getMidfieldering();
  gr += getAttacking();
  return gr;
}
