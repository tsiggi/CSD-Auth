#ifndef GOALIE_H
#define GOALIE_H

#include "Player.h"

class Goalie : public Player {
private:
  int saves;
  int a_goals;
  double getGoaling();

public:
  Goalie(char *n, int a, int h, double w, int p, bool i, int s, int l);
  double getGrade();
};

#endif
