#include "Goalie.h"

Goalie::Goalie(char *n, int a, int h, double w, int p, bool i, int s, int ag)
    : Player(n, a, h, w, p, i) {
  this->saves = s;
  this->a_goals = ag;
}

double Goalie::getGoaling() { return ((double)saves) / a_goals; }

double Goalie::getGrade() { return Player::getGrade() + 2 * getGoaling(); }
