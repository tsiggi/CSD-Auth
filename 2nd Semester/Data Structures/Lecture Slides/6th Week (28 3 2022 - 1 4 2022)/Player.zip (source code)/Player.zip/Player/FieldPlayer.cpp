#include "FieldPlayer.h"
#include <string.h>

FieldPlayer::FieldPlayer(char *n, int a, int h, double w, int p, bool i, int s,
                         int g, int ap, int pa, int at, int t)
    : Player(n, a, h, w, p, i)

{
  this->shots = s;
  this->goals = g;
  this->a_passes = ap;
  this->passes = pa;
  this->a_tackles = at;
  this->tackles = t;
}

double FieldPlayer::getDefending() { return (double)tackles / a_tackles; }

double FieldPlayer::getMidfieldering() { return (double)passes / a_passes; }

double FieldPlayer::getAttacking() { return (double)goals / shots; }
