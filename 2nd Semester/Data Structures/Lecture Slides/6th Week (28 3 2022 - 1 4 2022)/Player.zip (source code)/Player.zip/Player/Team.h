#ifndef TEAM_H
#define TEAM_H

#include "Player.h"

class Team {
private:
  char *name;
  int year;
  Player *lineup[30];
  int numPlayers;

public:
  Team(char *name, int year);
  ~Team();
  void addPlayer(Player *k);
  Player *getPlayer(int k);
  double avgAge();
  double sumGrade();
};
#endif