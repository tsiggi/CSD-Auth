#ifndef PLAYER_H
#define PLAYER_H

class Player {
private:
  char *name;             //όνομα
  int age;                //ηλικία
  int height;             // ύψος
  double weight;          // βάρος
  int played_games;       // συμμετοχές
  bool international;     // διεθνής
  double getExperience(); // T
  double getPhysical();   // P
public:
  Player(char *n, int a, int h, double w, int g, bool i);
  ~Player();
  char *getName();
  int getAge();
  virtual double getGrade();
};

#endif