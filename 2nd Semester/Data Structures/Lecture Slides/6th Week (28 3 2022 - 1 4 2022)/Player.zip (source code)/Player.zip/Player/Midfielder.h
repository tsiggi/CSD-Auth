#ifndef MIDFILDER_H
#define MIDFILDER_H

#include "FieldPlayer.h"

class Midfielder : public FieldPlayer {
public:
  Midfielder(char *n, int a, int h, double w, int p, bool i, int s, int g,
             int ap, int pa, int at, int t);
  double getGrade();
};
#endif