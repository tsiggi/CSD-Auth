#include "Player.h"
#include <stdlib.h>
#include <string.h>

Player::Player(char *s, int age, int h, double w, int p, bool i) {
  name = new char[strlen(s) + 1];
  strcpy(name, s);
  this->age = age;
  this->height = h;
  this->weight = w;
  this->played_games = p;
  this->international = i;
}

Player::~Player() { delete[] name; }

char *Player::getName() { return name; }

int Player::getAge() { return age; }

double Player::getExperience() {
  double exp;
  exp = ((double)played_games) / age;
  if (international)
    exp *= 1.5;
  return exp;
}

double Player::getPhysical() { return ((double)height) / weight; }

double Player::getGrade() {
  return 0.9 * getExperience() + 1.1 * getPhysical();
}