#include "Defender.h"

Defender::Defender(char *n, int a, int h, double w, int p, bool i, int s, int g,
                   int ap, int pa, int at, int t)
    : FieldPlayer(n, a, h, w, p, i, s, g, ap, p, at, t) {}

double Defender::getGrade() {
  double gr = Player::getGrade();
  gr += 2 * getDefending();
  gr += 1.4 * getMidfieldering();
  gr += getAttacking();
  return gr;
}
