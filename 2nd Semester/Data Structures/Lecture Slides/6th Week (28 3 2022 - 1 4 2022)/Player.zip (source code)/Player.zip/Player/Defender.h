#ifndef DEFENDER_H
#define DEFENDER_H

#include "FieldPlayer.h"

class Defender : public FieldPlayer {
public:
  Defender(char *n, int a, int h, double w, int p, bool i, int s, int g, int ap,
           int pa, int at, int t);
  double getGrade();
};

#endif
