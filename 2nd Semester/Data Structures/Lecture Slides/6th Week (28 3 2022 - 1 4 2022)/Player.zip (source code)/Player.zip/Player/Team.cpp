#include "Team.h"
#include <stdlib.h>
#include <string.h>

Team::Team(char *s, int year) {
  name = new char[strlen(s) + 1];
  strcpy(name, s);
  this->year = year;
  numPlayers = 0;
}

Team::~Team() { delete[] name; }

void Team::addPlayer(Player *k) {
  if (numPlayers < 30) {
    lineup[numPlayers] = k;
    numPlayers++;
  }
}

Player *Team::getPlayer(int k) {
  if (k < numPlayers) {
    return lineup[k];
  }
  return NULL;
}

double Team::avgAge() {
  int i;
  double sum = 0;
  if (numPlayers == 0)
    return 0;

  for (i = 0; i < numPlayers; i++)
    sum += lineup[i]->getAge();
  return (double) sum / numPlayers;
}

double Team::sumGrade() {
  int i;
  double sum = 0;
  if (numPlayers == 0)
    return 0;
  for (i = 0; i < numPlayers; i++)
    sum += lineup[i]->getGrade();
  return sum;
}
