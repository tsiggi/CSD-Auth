#include "Attacker.h"

Attacker::Attacker(char *n, int a, int h, double w, int p, bool i, int s, int g,
                   int ap, int pa, int at, int t)
    : FieldPlayer(n, a, h, w, p, i, s, g, ap, p, at, t) {}

double Attacker::getGrade() {
  double gr = FieldPlayer::getGrade();
  gr += 0.5 * getDefending();
  gr += 1.5 * getMidfieldering();
  gr += 2.5 * getAttacking();
  return gr;
}