#ifndef FIELD_PLAYER_H
#define FIELD_PLAYER_H

#include "Player.h"

class FieldPlayer : public Player {
private:
  int shots, goals;
  int a_passes, passes;
  int a_tackles, tackles;

protected:
  double getDefending();
  double getMidfieldering();
  double getAttacking();

public:
  FieldPlayer(char *n, int a, int h, double w, int p, bool i, int s, int g,
              int ap, int pa, int at, int t);
};
#endif