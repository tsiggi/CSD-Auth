// #include "Defender.h"
// #include <iostream>

// using namespace std;

// int main(int argc, char *argv[]) {
//   Player k((char *)"Urko Pardo", 25, 190, 88, 31, false);
//   Defender l((char *)"Katsiabis", 33, 190, 88, 31, false, 50, 3, 130, 100,
//   230,
//              175);
//   cout << k.getGrade() << endl;
//   cout << l.getGrade() << endl;
// }

#include "Defender.h"
#include "Team.h"
#include <cstdlib>
#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
  Player k((char *)"Urko Pardo", 25, 190, 88, 31, false);
  Defender l((char *)"Katsiabis", 33, 190, 88, 31, false, 50, 3, 130, 100, 230,
             175);
  cout << k.getGrade() << endl;
  cout << l.getGrade() << endl;
  Team iraklis((char *)"Iraklis", 1908);
  iraklis.addPlayer(&k);
  iraklis.addPlayer(&l);
  Player *a;
  a = iraklis.getPlayer(0);
  if (a != NULL)
    cout << a->getAge() << endl;
  cout << iraklis.avgAge() << endl;
  cout << iraklis.sumGrade() << endl;
  return EXIT_SUCCESS;
}
